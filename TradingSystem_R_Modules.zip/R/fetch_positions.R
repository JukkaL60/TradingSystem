# fetch_positions.R — hakee positiot Saxo API:sta
.clean_names <- function(x) {
  x <- sub("^PositionBase\.", "", x)
  x <- sub("^PositionView\.", "", x)
  x <- sub("^DisplayAndFormat\.", "", x)
  x
}
.flatten_if_needed <- function(df) {
  if (is.data.frame(df) && any(vapply(df, is.list, logical(1)))) jsonlite::flatten(df) else df
}
.supports_arg <- function(fun, arg) {
  arg %in% names(formals(fun))
}

fetch_positions <- function(){
  if (exists("saxo_get_positions")) {
    if (.supports_arg(saxo_get_positions, "field_groups")) {
      pos <- saxo_get_positions(field_groups = "PositionBase,PositionView,DisplayAndFormat")
      df  <- if (!is.null(pos$Data)) pos$Data else pos
      df  <- .flatten_if_needed(df)
    } else {
      if (exists(".saxo_req") && exists(".saxo_perform")) {
        req  <- .saxo_req("port/v1/positions/me") |> httr2::req_url_query(FieldGroups = "PositionBase,PositionView,DisplayAndFormat")
        resp <- .saxo_perform(req)
        body <- httr2::resp_body_json(resp, simplifyVector = TRUE)
        df   <- .flatten_if_needed(body$Data)
      } else {
        stop("saxo_get_positions() ei tue field_groups-parametria eikä alitason req/perform -funktioita löydy.")
      }
    }
  } else {
    message("⚠️ saxo_get_positions puuttuu — palautetaan tyhjä positions_df.")
    df <- data.frame()
  }

  want <- c(
    "NetPositionId","PositionBase.AccountId","PositionBase.AccountKey",
    "PositionBase.Uic","PositionBase.AssetType","PositionBase.Amount",
    "PositionBase.OpenPrice","PositionBase.OpenPriceIncludingCosts",
    "PositionBase.ExecutionTimeOpen","PositionBase.Status",
    "PositionView.CalculationReliability",
    "DisplayAndFormat.Symbol","DisplayAndFormat.Description","DisplayAndFormat.Currency"
  )
  keep <- intersect(want, names(df))
  out  <- if (length(keep)) df[, keep, drop=FALSE] else df
  names(out) <- .clean_names(names(out))
  out
}

positions_df <- tryCatch(fetch_positions(), error=function(e){
  message("⚠️ fetch_positions: ", conditionMessage(e))
  data.frame(Uic=integer(), NetPositionId=character(), Amount=double(),
             AverageOpenPrice=double(), stringsAsFactors=FALSE)
})

# Takaisinpäin-yhteensopivuus: jos AverageOpenPrice puuttuu, täytetään OpenPrice:lla
if (nrow(positions_df)){
  if (!"AverageOpenPrice" %in% names(positions_df) && "OpenPrice" %in% names(positions_df)) {
    positions_df$AverageOpenPrice <- positions_df$OpenPrice
  }
}
