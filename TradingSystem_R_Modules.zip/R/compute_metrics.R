# compute_metrics.R — laskee perusmittarit (quotes valinnainen)
if (!exists("positions_df")) stop("positions_df puuttuu (compute_metrics)")

# quotes_df on valinnainen; jos puuttuu, käytä NA / midhintaa jos Bid/Ask löytyy
if (!exists("quotes_df")) {
  quotes_df <- unique(positions_df["Uic"])
  quotes_df$LastTraded <- NA_real_
  quotes_df$Bid <- NA_real_
  quotes_df$Ask <- NA_real_
}

suppressWarnings({
  metrics_df <- dplyr::left_join(positions_df, quotes_df, by = "Uic") |>
    dplyr::mutate(
      LastPrice    = dplyr::coalesce(LastTraded, (Bid + Ask) / 2),
      MarketValue  = Amount * LastPrice,
      CostValue    = Amount * AverageOpenPrice,
      UnrealizedPL = MarketValue - CostValue,
      PL_pct       = dplyr::if_else(CostValue != 0, UnrealizedPL / CostValue, NA_real_)
    )
})
