# env_setup.R — paketit ja perusasetukset
quiet_lib <- function(p){ if(!requireNamespace(p, quietly=TRUE)) message("ℹ️ Paketti puuttuu: ", p) }
invisible(lapply(c("httr2","jsonlite","dplyr","readr","lubridate","stringr"), quiet_lib))
options(stringsAsFactors = FALSE)
