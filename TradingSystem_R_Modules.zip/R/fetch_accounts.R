# fetch_accounts.R — hakee tilitiedot Saxo API:sta
.flatten_if_needed <- function(df) {
  if (is.data.frame(df) && any(vapply(df, is.list, logical(1)))) jsonlite::flatten(df) else df
}

fetch_accounts <- function(){
  if (exists("saxo_get_accounts")) {
    acc <- saxo_get_accounts()
    df <- if (!is.null(acc$Data)) acc$Data else acc
    .flatten_if_needed(df)
  } else if (exists(".saxo_req") && exists(".saxo_perform")) {
    req <- .saxo_req("port/v1/accounts/me")
    resp <- .saxo_perform(req)
    body <- httr2::resp_body_json(resp, simplifyVector = TRUE)
    .flatten_if_needed(body$Data)
  } else {
    message("⚠️ Ei suoraa Saxo-kutsua saatavilla. Palautetaan tyhjä accounts_df.")
    data.frame(AccountId=character(), AccountKey=character(), stringsAsFactors=FALSE)
  }
}

accounts_df <- tryCatch(fetch_accounts(), error=function(e){
  message("⚠️ fetch_accounts: ", conditionMessage(e))
  data.frame(AccountId=character(), AccountKey=character(), stringsAsFactors=FALSE)
})
