# auth_saxo.R — varmistaa autentikoinnin Saxo OpenAPI:in
# Käyttää olemassa olevaa saxo_auth_live()-funktiota jos se on saatavilla.
ensure_saxo_auth <- function(){
  if (exists("saxo_auth_live")) {
    message("🔑 Autentikoidaan Saxo (saxo_auth_live) ...")
    saxo_auth_live() # asettaa tokenin oman toteutuksesi mukaisesti
    message("✅ Auth OK.")
  } else if (exists("saxo_token") && length(saxo_token)) {
    message("ℹ️ Käytetään jo olemassa olevaa saxo_token-arvoa.")
  } else {
    message("⚠️ Saxo OAuth -funktio puuttuu (saxo_auth_live). Jatketaan ilman live-authia.")
    if (!exists("saxo_token")) saxo_token <- list(access_token="SIM_TOKEN")
    assign("saxo_token", saxo_token, envir=.GlobalEnv)
  }
}
ensure_saxo_auth()
